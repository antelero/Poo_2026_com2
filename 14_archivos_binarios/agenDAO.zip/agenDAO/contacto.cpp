#include "contacto.h"

Contacto::Contacto() {
    id_persona = 0;
}

Contacto::Contacto(string tipo, string valor) {
    id_persona = 0;
    this->tipo = tipo;
    this->valor = valor;
}

int Contacto::getId_persona() {
    return id_persona;
}

void Contacto::setId_persona(int id) {
    id_persona = id;
}

string Contacto::getTipo() {
    return tipo;
}

string Contacto::getValor() {
    return valor;
}

void Contacto::setTipo(string tipo) {
    this->tipo = tipo;
}

void Contacto::setValor(string valor) {
    this->valor = valor;
}
