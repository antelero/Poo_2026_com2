#include "personadaosql.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QDebug>

PersonaDaoSql::PersonaDaoSql() {
    // Configura la conexión a la base de datos local SQLite
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("agenda.db");

    if (!db.open()) {
        qDebug() << "Error al abrir la base de datos:" << db.lastError().text();
    } else {
        initDatabase();
    }
}

PersonaDaoSql::~PersonaDaoSql() {
    if (db.isOpen()) {
        db.close();
    }
}

void PersonaDaoSql::initDatabase() {
    QSqlQuery query;

    // 1. Tabla de Personas
    QString sqlPersonas = "CREATE TABLE IF NOT EXISTS personas ("
                          "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                          "nombre TEXT, "
                          "direccion TEXT);";
    if (!query.exec(sqlPersonas)) {
        qDebug() << "Error al crear tabla personas:" << query.lastError().text();
    }

    // 2. Tabla de Contactos (relacionada con personas mediante persona_id)
    QString sqlContactos = "CREATE TABLE IF NOT EXISTS contactos ("
                           "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                           "persona_id INTEGER, "
                           "tipo TEXT, "
                           "valor TEXT, "
                           "FOREIGN KEY(persona_id) REFERENCES personas(id));";
    if (!query.exec(sqlContactos)) {
        qDebug() << "Error al crear tabla contactos:" << query.lastError().text();
    }
}

std::vector<Persona> PersonaDaoSql::leerTodo() {
    std::vector<Persona> listaPersonas;
    QSqlQuery queryPersona("SELECT id, nombre, direccion FROM personas");

    while (queryPersona.next()) {
        int idPersona = queryPersona.value("id").toInt();
        QString nombre = queryPersona.value("nombre").toString();
        QString direccion = queryPersona.value("direccion").toString();

        // Convertimos QString a char* compatible con tu constructor
        // Usamos QByteArray para mantener los datos vivos durante la asignación
        QByteArray nombreBa = nombre.toLocal8Bit();
        Persona p(nombreBa.data());
        p.setId(idPersona);

        QByteArray dirBa = direccion.toLocal8Bit();
        p.setDir(dirBa.data());

        // --- Cargar los Contactos de esta Persona ---
        QSqlQuery queryContacto;
        queryContacto.prepare("SELECT tipo, valor FROM contactos WHERE persona_id = ?");
        queryContacto.addBindValue(idPersona);

        if (queryContacto.exec()) {
            while (queryContacto.next()) {
                QString tipo = queryContacto.value("tipo").toString();
                QString valor = queryContacto.value("valor").toString();

                // Asumiendo que tu clase Contacto tiene un constructor Contacto(tipo, valor)
                // Adapta esta parte según cómo esté definida tu clase Contacto
                Contacto c(tipo.toStdString(), valor.toStdString());
                p.addContacto(c);
            }
        }

        listaPersonas.push_back(p);
    }

    return listaPersonas;
}

bool PersonaDaoSql::guardar(Persona persona) {
    QSqlQuery query;

    // 1. Insertar la Persona
    query.prepare("INSERT INTO personas (nombre, direccion) VALUES (?, ?)");
    query.addBindValue(QString(persona.getNombre()));
    query.addBindValue(QString(persona.getDir()));

    if (!query.exec()) {
        qDebug() << "Error al insertar persona:" << query.lastError().text();
        return false;
    }

    // OBTENER EL ID generado automáticamente por SQLite para esta persona
    int idGenerado = query.lastInsertId().toInt();

    // 2. Insertar sus Contactos asociados
    std::vector<Contacto> contactos = persona.getContactos();
    for (const Contacto& c : contactos) {
        QSqlQuery queryContacto;
        queryContacto.prepare("INSERT INTO contactos (persona_id, tipo, valor) VALUES (?, ?, ?)");
        queryContacto.addBindValue(idGenerado);

        // Reemplaza 'getTipo()' y 'getValor()' por los métodos reales de tu clase Contacto
        queryContacto.addBindValue(QString::fromStdString(c.getTipo()));
        queryContacto.addBindValue(QString::fromStdString(c.getValor()));

        if (!queryContacto.exec()) {
            qDebug() << "Error al insertar contacto:" << queryContacto.lastError().text();
        }
    }

    return true;
}
