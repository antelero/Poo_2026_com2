#include "agenda.h"
#include "personadaofile.h"
#include "personadaofiletxt.h"
#include "personadaomem.h"
#include "personadaosql.h"
#include <string.h>

const std::vector<Persona> &Agenda::getPersonas() const
{
    return personas;
}

Agenda::Agenda()
{
    //this->dao = new PersonaDaoFile();
    //this->dao = new PersonaDaoMem();
    //this->dao = new PersonaDaoSql();
    this->dao = new PersonaDaoFileTxt();
}

void Agenda::leer()
{
    this->personas = this->dao->leerTodo();
}

bool Agenda::save(Persona persona)
{
    this->personas.push_back(persona);
    this->dao->guardar(persona);
}

void Agenda::generarDatosDeEjemplo()
{
    this->dao->generarDatosDeEjemplo();
}

std::vector<Persona> Agenda::filtrar(char *nombre)
{
    std::vector<Persona> aux;
    for (int i = 0; i < this->personas.size(); i++) {
        auto p = this->personas[i];
        int len = strlen(nombre);
        if (strncmp(p.getNombre(), nombre, len) == 0) {
            aux.push_back(p);
        }
    }
    return aux;
}



bool Agenda::agregarContactoAPersona(int idPersona, const std::string& tipo, const std::string& valor)
{
    // 1. Recorremos por referencia (auto&) para modificar el objeto real en la lista
    for (auto& persona : personas) {
        if (persona.getId() == idPersona) {

            // 2. Creamos la instancia de Contacto
            Contacto c(tipo.c_str(), valor.c_str());

            // 3. Usamos el método que ya definiste en tu clase Persona
            persona.addContacto(c);

            return true; // Encontrado y agregado exitosamente
        }
    }
    return false; // No se encontró la persona con ese ID
}
