#ifndef PERSONADAOSQL_H
#define PERSONADAOSQL_H

#include <vector>
#include <QSqlDatabase>
#include "persona.h" // Asegúrate de que el nombre coincida con tu clase Persona

class PersonaDaoSql {
private:
    QSqlDatabase db;
    void initDatabase(); // Método auxiliar para crear la tabla si no existe

public:
    PersonaDaoSql();
    ~PersonaDaoSql();

    std::vector<Persona> leerTodo();
    bool guardar(Persona persona);
};

#endif // PERSONADAOSQL_H
