#ifndef CONTACTO_H
#define CONTACTO_H
#include <string>
using namespace std;

class Contacto {
private:
    int id_persona;      // <-- nuevo atributo
    string tipo;
    string valor;

public:
    Contacto();
    Contacto(string tipo, string valor);

    // Getters
    int getId_persona();
    string getTipo();
    string getValor();

    // Setters
    void setId_persona(int id);
    void setTipo(string tipo);
    void setValor(string valor);
};

#endif // CONTACTO_H
